# TempShell X — Android Studio source starter

A Kotlin/Jetpack Compose Android companion app. This project is source code, not a signed APK. The project is configured for Android 7.0 (API 24) through Android 16 (API 36) at the app/platform level.

## Included in this first scaffold
- Dark dashboard and root availability check (`su -c id`)
- Basic manager detection (`ksud`, Magisk, KernelSU device node)
- Module list from `/data/adb/modules`
- Enable/disable/uninstall markers with confirmation dialogs
- ZIP picker and `module.prop` validation
- FinaSU/KernelSU `ksud module install <zip>` integration
- One-command-at-a-time root terminal

## Important safety notes
- Root must already be installed and explicitly granted by the device's root manager.
- No LPE, boot-image patching, bootloader bypass, kernel exploit, or automatic root acquisition is included.
- A module ZIP can execute privileged scripts and alter system behavior. Only install packages from sources you trust.
- ZIP inspection here validates the root-level `module.prop` and module ID; it is not a malware scanner or cryptographic trust check.
- Kernel `.ko` loading is intentionally not included; it is a separate, device/kernel-specific operation.
- The terminal currently launches one root shell per command; persistent PTY sessions, cancellation, streaming output and audit persistence are follow-up work.
- The module flash command is documented by FinaSU as `ksud module install`. The app checks for `ksud` before invoking it. Verify the installed manager version/API on your device before using module flashing.
- This starter does not yet implement a full module backup/restore, repository, signature allowlist, or compatibility database.

## Build
1. Open this folder in Android Studio with Android SDK 36 installed.
2. Allow Gradle sync.
3. Build > Build APK(s).
4. Test on a spare device with a recoverable stock boot image and a known-good module first.

## Toolchain
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Compose BOM 2025.01.00
- minSdk 24 (Android 7.0), target/compile SDK 36 (Android 16)

If Android Studio asks to update the Gradle wrapper, use the version compatible with the selected Android Gradle Plugin.


## Compatibility qualification
The API range is a build target, not a guarantee that every feature works on every Android release or device. Root-manager interfaces, module paths, permissions, vendor kernels, and exploit compatibility vary by firmware. This scaffold does not include TempShell's kernel-exploit payload or automatic root acquisition, so it is not functionally equivalent to the original TempShell.
\n\nBuild compatibility fix: Java and Kotlin bytecode targets are both set to JVM 17.\n
Java and Kotlin bytecode targets are both configured as JVM 1.8 to keep the compiler targets aligned.
