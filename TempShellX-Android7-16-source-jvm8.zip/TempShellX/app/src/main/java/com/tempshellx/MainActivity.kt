package com.tempshellx

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

private val Bg = Color(0xFF0B1018)
private val Panel = Color(0xFF151E2B)
private val Accent = Color(0xFF70E0B0)
private val Muted = Color(0xFF9BAABD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TempShellXApp(this) }
    }
}

data class RootResult(val code: Int, val output: String) {
    val ok get() = code == 0
}

data class ModuleInfo(
    val id: String, val name: String, val version: String,
    val author: String, val description: String,
    val enabled: Boolean, val pendingRemoval: Boolean
)

private object RootShell {
    suspend fun run(command: String): RootResult = withContext(Dispatchers.IO) {
        try {
            val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            RootResult(code, output.trim())
        } catch (t: Throwable) {
            RootResult(127, "Root shell unavailable: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
}

private suspend fun detectRoot(): String {
    val result = RootShell.run("id")
    return if (result.ok && result.output.contains("uid=0")) "Root authorized" else "Root not available"
}

private suspend fun detectManager(): String {
    val checks = listOf(
        "command -v ksud >/dev/null 2>&1 && echo FinaSU/KernelSU (ksud)",
        "command -v magisk >/dev/null 2>&1 && echo Magisk",
        "test -e /dev/kernelsu && echo KernelSU driver"
    )
    val found = checks.map { RootShell.run(it) }.filter { it.ok && it.output.isNotBlank() }
        .map { it.output.lines().last() }.distinct()
    return found.joinToString(" · ").ifBlank { "No manager detected" }
}

private suspend fun loadModules(): Pair<List<ModuleInfo>, String> {
    val r = RootShell.run(
        "for d in /data/adb/modules/*; do " +
        "[ -d \"$d\" ] || continue; " +
        "p=\"$d/module.prop\"; [ -f \"$p\" ] || continue; " +
        "echo \"__MODULE__$(basename \"$d\")\"; " +
        "grep -E '^(name|version|author|description)=' \"$p\" 2>/dev/null; " +
        "[ -e \"$d/disable\" ] && echo '__DISABLED__'; " +
        "[ -e \"$d/remove\" ] && echo '__REMOVE__'; " +
        "done"
    )
    if (!r.ok) return emptyList<ModuleInfo>() to r.output
    val modules = mutableListOf<ModuleInfo>()
    var id = ""
    var name = ""; var version = ""; var author = ""; var description = ""
    var disabled = false; var removal = false
    fun flush() {
        if (id.isNotBlank()) modules += ModuleInfo(id, name.ifBlank { id }, version, author,
            description, !disabled, removal)
    }
    r.output.lineSequence().forEach { line ->
        when {
            line.startsWith("__MODULE__") -> {
                flush()
                id = line.removePrefix("__MODULE__")
                name = ""; version = ""; author = ""; description = ""
                disabled = false; removal = false
            }
            line == "__DISABLED__" -> disabled = true
            line == "__REMOVE__" -> removal = true
            line.startsWith("name=") -> name = line.substringAfter("=")
            line.startsWith("version=") -> version = line.substringAfter("=")
            line.startsWith("author=") -> author = line.substringAfter("=")
            line.startsWith("description=") -> description = line.substringAfter("=")
        }
    }
    flush()
    modules.sortBy { it.name.lowercase() }
    return modules to ""
}

private fun inspectModuleZip(context: Context, uri: Uri): Pair<File?, String> {
    return try {
        val file = File(context.cacheDir, "module-${System.currentTimeMillis()}.zip")
        context.contentResolver.openInputStream(uri)?.use { input ->
            file.outputStream().use { output -> input.copyTo(output) }
        } ?: return null to "Cannot read selected file"
        if (file.length() > 512L * 1024L * 1024L) {
            file.delete(); return null to "ZIP exceeds 512 MiB safety limit"
        }
        ZipFile(file).use { zip ->
            val prop = zip.getEntry("module.prop")
                ?: run { file.delete(); return null to "Invalid module: module.prop must be at ZIP root" }
            if (prop.isDirectory) { file.delete(); return null to "module.prop is not a file" }
            val text = zip.getInputStream(prop).bufferedReader().use { it.readText().take(64 * 1024) }
            val id = Regex("(?m)^id=([A-Za-z][A-Za-z0-9._-]{1,127})\\s*$").find(text)?.groupValues?.get(1)
                ?: run { file.delete(); return null to "Invalid or missing module ID" }
            val name = Regex("(?m)^name=(.+)$").find(text)?.groupValues?.get(1)?.trim().orEmpty()
            return file to "Module: ${name.ifBlank { id }}\nID: $id\n\nModule installers can execute privileged scripts and modify system behavior. Install only trusted packages."
        }
    } catch (t: Throwable) {
        null to "ZIP inspection failed: ${t.message}"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TempShellXApp(context: Context) {
    var tab by remember { mutableStateOf("Home") }
    var rootStatus by remember { mutableStateOf("Checking…") }
    var manager by remember { mutableStateOf("Detecting…") }
    var modules by remember { mutableStateOf(emptyList<ModuleInfo>()) }
    var terminalInput by remember { mutableStateOf("id") }
    var terminalOutput by remember { mutableStateOf("TempShell X terminal ready. Commands run only after root authorization.") }
    var notice by remember { mutableStateOf("") }
    var pendingInstall by remember { mutableStateOf<Pair<File, String>?>(null) }
    var pendingAction by remember { mutableStateOf<Pair<ModuleInfo, String>?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun refresh() {
        rootStatus = detectRoot()
        manager = detectManager()
        val (list, error) = loadModules()
        modules = list
        if (error.isNotBlank()) notice = error
    }

    LaunchedEffect(Unit) { refresh() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val (file, message) = withContext(Dispatchers.IO) { inspectModuleZip(context, uri) }
                if (file != null) pendingInstall = file to message else notice = message
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("TEMPSHELL X", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("ROOT • MODULES • TERMINAL", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                        }
                    },
                    actions = { IconButton(onClick = { scope.launch { refresh() } }) { Icon(Icons.Default.Refresh, "Refresh") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Modules", "Terminal", "Logs").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when(item) {
                                    "Home" -> Icons.Default.Dashboard
                                    "Modules" -> Icons.Default.Apps
                                    "Terminal" -> Icons.Default.Terminal
                                    else -> Icons.Default.ReceiptLong
                                }, item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, indicatorColor = Color(0xFF263B3A))
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when (tab) {
                    "Home" -> {
                        Text("System overview", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        StatusCard("ROOT ACCESS", rootStatus, if (rootStatus == "Root authorized") Accent else Color(0xFFFFC36B))
                        StatusCard("ROOT MANAGER", manager, Accent)
                        StatusCard("INSTALLED MODULES", "${modules.size} detected", Accent)
                        Spacer(Modifier.height(10.dp))
                        Text("Safety", color = Accent, fontWeight = FontWeight.Bold)
                        Text("This app does not install or run kernel exploits. Root access must already be granted by your installed manager.", color = Muted)
                    }
                    "Modules" -> {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Module manager", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Button(onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed")) }) {
                                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Flash ZIP")
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("ZIP modules are privileged code. Review the source and module metadata before installation.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(modules, key = { it.id }) { module ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(module.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                        Text("${module.id} • ${module.version}", color = Muted, fontSize = 11.sp)
                                        if (module.description.isNotBlank()) Text(module.description, color = Muted, fontSize = 12.sp)
                                        Text(if (module.pendingRemoval) "Removal pending reboot" else if (module.enabled) "Enabled" else "Disabled",
                                            color = if (module.enabled) Accent else Color(0xFFFFC36B), fontSize = 12.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(onClick = { pendingAction = module to if (module.enabled) "disable" else "enable" }) {
                                                Text(if (module.enabled) "Disable" else "Enable")
                                            }
                                            OutlinedButton(onClick = { pendingAction = module to "remove" }) { Text("Uninstall") }
                                        }
                                    }
                                }
                            }
                            if (modules.isEmpty()) item { Text("No module metadata found. Refresh after granting root access.", color = Muted) }
                        }
                    }
                    "Terminal" -> {
                        Text("Root terminal", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Each command runs in a fresh root shell; use explicit authorization in your root manager.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF05080D))) {
                            Text(terminalOutput, Modifier.fillMaxWidth().padding(12.dp), color = Accent, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(value = terminalInput, onValueChange = { terminalInput = it }, modifier = Modifier.fillMaxWidth(),
                            label = { Text("Command") }, singleLine = true)
                        Button(onClick = {
                            val command = terminalInput.trim()
                            if (command.isNotBlank()) scope.launch {
                                val result = RootShell.run(command)
                                terminalOutput += "\n\n$ $command\n${result.output}\n[exit ${result.code}]"
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Run as root") }
                    }
                    else -> {
                        Text("Activity log", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Session output is shown in the Terminal tab. Persistent audit logging is planned for the next build.", color = Muted)
                    }
                }
            }
        }
    }

    if (pendingInstall != null) {
        val item = pendingInstall!!
        AlertDialog(
            onDismissRequest = { item.first.delete(); pendingInstall = null },
            title = { Text("Confirm module installation") },
            text = { Text(item.second) },
            confirmButton = {
                TextButton(onClick = {
                    pendingInstall = null
                    scope.launch {
                        val path = RootShell.quote(item.first.absolutePath)
                        val result = RootShell.run("command -v ksud >/dev/null 2>&1 || exit 127; ksud module install $path")
                        notice = if (result.ok) "Installer completed. Reboot may be required.\n${result.output}" else "Install failed (${result.code}). ${result.output}"
                        item.first.delete()
                        refresh()
                    }
                }) { Text("Install") }
            },
            dismissButton = { TextButton(onClick = { item.first.delete(); pendingInstall = null }) { Text("Cancel") } }
        )
    }

    if (pendingAction != null) {
        val (module, action) = pendingAction!!
        AlertDialog(
            onDismissRequest = { pendingAction = null },
            title = { Text("${action.replaceFirstChar { it.uppercase() }} ${module.name}?") },
            text = { Text("This changes the module's state in /data/adb/modules. The change may require a reboot. Only proceed if you understand the module's effect.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingAction = null
                    scope.launch {
                        val dir = RootShell.quote("/data/adb/modules/${module.id}")
                        val cmd = when(action) {
                            "disable" -> "touch $dir/disable"
                            "enable" -> "rm -f $dir/disable"
                            else -> "touch $dir/remove"
                        }
                        val result = RootShell.run(cmd)
                        notice = result.output.ifBlank { if (result.ok) "Module state updated; reboot may be required." else "Operation failed." }
                        refresh()
                    }
                }) { Text("Confirm") }
            },
            dismissButton = { TextButton(onClick = { pendingAction = null }) { Text("Cancel") } }
        )
    }

    if (notice.isNotBlank()) {
        AlertDialog(onDismissRequest = { notice = "" }, title = { Text("TempShell X") },
            text = { Text(notice) }, confirmButton = { TextButton(onClick = { notice = "" }) { Text("OK") } })
    }
}

@Composable
private fun StatusCard(title: String, value: String, tint: Color) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 10.sp, letterSpacing = 1.2.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = tint, fontWeight = FontWeight.SemiBold)
        }
    }
}
